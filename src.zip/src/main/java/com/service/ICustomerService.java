package com.service;

import java.util.List;
import java.util.Optional;

import com.entity.Address;
import com.entity.Customer;

public interface ICustomerService {
	
	Customer addCustomer(Customer customer);
	
	Customer updateCustomer(Customer tenant);

	Customer deleteCustomer(Integer customerId);

	Customer viewCustomer(Integer customerId);	

	List<Customer> viewAllCustomers();

	boolean validateCustomer(String userName, String password);
	
	List<Object[]> viewOrders(Integer customerId);
	
	Customer updateAddress(Integer customerId, Address address);

	List<Customer> getAllCustomer();

	//Optional<Customer> findByUsernameAndPassword(String username, String password);

}