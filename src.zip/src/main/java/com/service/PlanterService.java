package com.service;

import java.util.List;

import com.entity.Plant;
import com.entity.Planterp;


public interface PlanterService {

	Planterp addPlanter(Planterp planter);
	
	List<Planterp> getAllPlanter();
	
	 

	Planterp updatePlanter(Planterp e) throws Throwable;

	String deletePlanterById(int planterId);

	Planterp getPlanterById(int planterId) throws Throwable;


	
}
