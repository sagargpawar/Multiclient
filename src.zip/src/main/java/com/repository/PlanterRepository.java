package com.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


import com.entity.Planterp;

@Repository
public interface PlanterRepository extends JpaRepository<Planterp, Integer> {

}
