package com.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.entity.GardenDecor;

public interface GardenDecorRepository extends JpaRepository<GardenDecor, Integer>{

	

}
