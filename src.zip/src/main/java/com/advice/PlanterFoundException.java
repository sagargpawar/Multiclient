package com.advice;

public class PlanterFoundException extends RuntimeException{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PlanterFoundException(String message) {
		super(message);
	}
}