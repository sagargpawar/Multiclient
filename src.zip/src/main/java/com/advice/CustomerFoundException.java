package com.advice;

public class CustomerFoundException extends RuntimeException{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public CustomerFoundException(String message) {
		super(message);
	}

}
