package com.advice;

public class PlantFoundException extends RuntimeException{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PlantFoundException(String message) {
		super(message);
	}
}
