package com.advice;

public class SeedFoundException extends RuntimeException{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public SeedFoundException(String message) {
		super(message);
	}
}