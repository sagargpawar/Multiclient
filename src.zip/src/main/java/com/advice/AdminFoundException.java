package com.advice;

public class AdminFoundException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public AdminFoundException(String message) {
		super(message);
	}

}

