package com.advice;

public class PlanterNotFoundException extends RuntimeException{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PlanterNotFoundException(String message) {
		super(message);
	}
}
